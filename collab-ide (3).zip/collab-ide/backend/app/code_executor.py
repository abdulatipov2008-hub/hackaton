import docker 
import asyncio
import tempfile
import os
from typing import Dict
from docker.errors import DockerException, ContainerError

class CodeExecutor:
    def __init__(self):
        try:
            self.client = docker.from_env()
            # Проверка подключения
            self.client.ping()
            print("✅ Docker connected successfully")
        except DockerException as e:
            print(f"❌ Docker connection error: {e}")
            self.client = None
            
    async def execute(self, code: str, language: str = "python", timeout: int = 10) -> str:
        """Execute code in Docker container"""
        if self.client is None:
            return "Error: Docker is not available. Please install and start Docker Desktop."
            
        if language not in self.language_configs:
            raise ValueError(f"Unsupported language: {language}")
        
        config = self.language_configs[language]
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            self._execute_sync,
            code, config, timeout
        )
    
    def _execute_sync(self, code: str, config: Dict, timeout: int) -> str:
        """Synchronous execution logic"""
        with tempfile.TemporaryDirectory() as tmpdir:
            code_file = os.path.join(tmpdir, config["file"])
            with open(code_file, "w", encoding="utf-8") as f:
                f.write(code)
            
            try:
                container = self.client.containers.run(
                    config["image"],
                    command=config["command"],
                    volumes={tmpdir: {"bind": "/app", "mode": "ro"}},
                    mem_limit="128m",
                    network_disabled=True,
                    remove=True,
                    detach=True
                )
                
                try:
                    result = container.wait(timeout=timeout)
                    logs = container.logs().decode("utf-8", errors="replace")
                    return logs.strip() or "No output"
                except Exception as e:
                    try:
                        container.kill()
                    except:
                        pass
                    return f"Execution error: {str(e)}"
                    
            except ContainerError as e:
                return f"Container error: {e.stderr.decode('utf-8', errors='replace') if e.stderr else str(e)}"
            except DockerException as e:
                return f"Docker error: {str(e)}"
            except Exception as e:
                return f"Error: {str(e)}"
    
    language_configs = {
        "python": {
            "image": "python:3.11-slim",
            "command": "python /app/code.py",
            "file": "code.py"
        },
        "javascript": {
            "image": "node:20-slim",
            "command": "node /app/code.js",
            "file": "code.js"
        }
    }
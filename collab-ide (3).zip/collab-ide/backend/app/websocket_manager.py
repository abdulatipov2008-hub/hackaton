from fastapi import WebSocket
from typing import Dict, List, Set
import json

class ConnectionManager:
    def __init__(self):
        # room_id -> {client_id -> WebSocket}
        self.rooms: Dict[str, Dict[str, WebSocket]] = {}
    
    async def connect(self, websocket: WebSocket, room_id: str, client_id: str):
        await websocket.accept()
        
        if room_id not in self.rooms:
            self.rooms[room_id] = {}
        
        self.rooms[room_id][client_id] = websocket
        
        # Notify others about new participant
        await self.broadcast_to_room(
            room_id,
            {"type": "participant_joined", "client_id": client_id},
            exclude=websocket
        )
    
    def disconnect(self, room_id: str, client_id: str):
        if room_id in self.rooms and client_id in self.rooms[room_id]:
            del self.rooms[room_id][client_id]
            
            if not self.rooms[room_id]:
                del self.rooms[room_id]
    
    async def broadcast_to_room(self, room_id: str, message: dict, exclude: WebSocket = None):
        """Broadcast message to all clients in room"""
        if room_id not in self.rooms:
            return
        
        disconnected = []
        for client_id, websocket in self.rooms[room_id].items():
            if websocket == exclude:
                continue
            try:
                await websocket.send_json(message)
            except:
                disconnected.append(client_id)
        
        # Clean up disconnected clients
        for client_id in disconnected:
            self.disconnect(room_id, client_id)
    
    async def send_to_client(self, room_id: str, client_id: str, message: dict):
        """Send message to specific client"""
        if room_id in self.rooms and client_id in self.rooms[room_id]:
            try:
                await self.rooms[room_id][client_id].send_json(message)
            except:
                self.disconnect(room_id, client_id)
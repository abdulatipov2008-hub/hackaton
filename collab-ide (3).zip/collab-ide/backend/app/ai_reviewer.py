import openai
from typing import Optional, Dict
import os
import json

class AIReviewer:
    def __init__(self):
        self.client = openai.AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.review_history = {}
    
    async def review_code(self, code: str, language: str = "python") -> Optional[Dict]:
        """Review code using LLM"""
        if not code or len(code) < 10:
            return None
        
        backticks = "```"
        prompt = f"""Analyze this {language} code and provide:
1. Potential bugs or errors
2. Security vulnerabilities
3. Code style issues
4. Performance improvements
5. Best practices violations

Code:
{backticks}{language}
{code}
{backticks}

Provide response in JSON format with fields: issues, suggestions, score (0-10)"""

        try:
            response = await self.client.chat.completions.create(
                model="gpt-4-turbo-preview",
                messages=[
                    {"role": "system", "content": "You are an expert code reviewer."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=500,
                temperature=0.3
            )
            
            review = json.loads(response.choices[0].message.content)
            
            conflicts = self.detect_conflicts(code)
            if conflicts:
                review["conflicts"] = conflicts
            
            return review
            
        except Exception as e:
            print(f"AI Review error: {e}")
            return None
    
    def detect_conflicts(self, code: str) -> list:
        """Detect potential merge conflicts"""
        conflicts = []
        
        if "TODO" in code or "FIXME" in code:
            conflicts.append({"type": "incomplete", "message": "Incomplete code detected"})
        
        if "eval(" in code:
            conflicts.append({
                "type": "security",
                "message": "Use of eval() is dangerous",
                "severity": "high"
            })
        
        return conflicts
    

    async def suggest_merge(self, version1: str, version2: str) -> str:
        """Suggest optimal merge solution"""
        try:
            backticks = "```"
            prompt = f"""Merge these two versions of code optimally:

Version 1:
{backticks}python
{version1}
{backticks}

Version 2:
{backticks}python
{version2}
{backticks}

Provide merged code that incorporates changes from both versions."""

            response = await self.client.chat.completions.create(
                model="gpt-4-turbo-preview",
                messages=[
                    {"role": "system", "content": "You are a code merge expert."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.5
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            print(f"Merge suggestion error: {e}")
            return version1
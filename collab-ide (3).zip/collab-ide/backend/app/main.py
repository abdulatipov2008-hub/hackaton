from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, List
import json
from datetime import datetime




app = FastAPI(title="Collaborative IDE")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Хранилища
active_rooms: Dict[str, Dict[str, WebSocket]] = {}
room_content: Dict[str, str] = {}
executor = CodeExecutor()
@app.get("/")
async def root():
    return {"message": "Collaborative IDE API", "status": "running"}

@app.get("/health")
async def health():
    return {"status": "healthy", "database": "connected"}

@app.websocket("/ws/{room_id}/{client_id}")
async def websocket_endpoint(websocket: WebSocket, room_id: str, client_id: str):
    await websocket.accept()
    print(f"🔌 [{room_id}] Client {client_id} connected")
    
    # Инициализация комнаты
    if room_id not in active_rooms:
        active_rooms[room_id] = {}
        room_content[room_id] = "// Start coding...\n"
        print(f"📁 [{room_id}] Room created")
    
    active_rooms[room_id][client_id] = websocket
    print(f"👥 [{room_id}] Total participants: {len(active_rooms[room_id])}")
    
    # Отправляем текущий контент
    init_data = {
        "type": "init",
        "content": room_content[room_id],
        "participants": len(active_rooms[room_id])
    }
    await websocket.send_json(init_data)
    print(f"📤 [{room_id}] Sent init to {client_id} ({len(room_content[room_id])} chars)")
    
    # Уведомляем других
    await broadcast_to_room(room_id, {
        "type": "participant_joined",
        "client_id": client_id,
        "participants": len(active_rooms[room_id])
    }, exclude=client_id)
    
    try:
        while True:
            # Получаем сообщение
            data = await websocket.receive_text()
            print(f"📥 [{room_id}] Received from {client_id}: {len(data)} bytes")
            
            message = json.loads(data)
            msg_type = message.get("type", "unknown")
            print(f"   → Type: {msg_type}")
            
            if msg_type == "content_change":
                content = message.get("content", "")
                print(f"💾 [{room_id}] Saving content ({len(content)} chars) from {client_id}")
                
                # Сохраняем
                room_content[room_id] = content
                
                # Рассылаем ВСЕМ (включая отправителя)
                sent_count = await broadcast_to_room(room_id, {
                    "type": "content_change",
                    "content": content,
                    "client_id": client_id,
                    "timestamp": datetime.now().isoformat()
                })
                print(f"📡 [{room_id}] Broadcasted to {sent_count} clients")
    
    except WebSocketDisconnect:
        print(f"❌ [{room_id}] Client {client_id} disconnected")
        if room_id in active_rooms and client_id in active_rooms[room_id]:
            del active_rooms[room_id][client_id]
            
            await broadcast_to_room(room_id, {
                "type": "participant_left",
                "client_id": client_id,
                "participants": len(active_rooms[room_id]) if room_id in active_rooms else 0
            })
            
            # Удаляем пустую комнату
            if room_id in active_rooms and not active_rooms[room_id]:
                del active_rooms[room_id]
                if room_id in room_content:
                    del room_content[room_id]
                print(f"🗑️ [{room_id}] Room deleted (empty)")

async def broadcast_to_room(room_id: str, message: dict, exclude: str = None) -> int:
    """Отправить сообщение всем клиентам в комнате. Возвращает количество успешных отправок."""
    if room_id not in active_rooms:
        return 0
    
    sent_count = 0
    disconnected = []
    
    for cid, ws in active_rooms[room_id].items():
        if cid == exclude:
            continue
        
        try:
            await ws.send_json(message)
            print(f"   → Sent to {cid}")
            sent_count += 1
        except Exception as e:
            print(f"   ❌ Failed to send to {cid}: {e}")
            disconnected.append(cid)
    
    # Удаляем отключившихся
    for cid in disconnected:
        if room_id in active_rooms and cid in active_rooms[room_id]:
            del active_rooms[room_id][cid]
    
    return sent_count

@app.get("/api/rooms/{room_id}/participants")
async def get_participants(room_id: str):
    if room_id in active_rooms:
        return {
            "count": len(active_rooms[room_id]),
            "clients": list(active_rooms[room_id].keys())
        }
    return {"count": 0, "clients": []}

# backend/app/main.py — добавьте ВОТ ЭТОТ БЛОК

from app.code_executor import CodeExecutor
import asyncio

# Создаём один экземпляр executor (можно также создавать на каждый запрос — но так эффективнее)
executor = CodeExecutor()

@app.post("/api/execute")
async def execute_code(data: dict):
    code = data.get("code", "")
    language = data.get("language", "python")
    if not code.strip():
        return {"success": False, "error": "Empty code"}

    try:
        output = await executor.execute(code, language, timeout=10)
        return {"": True, "output": output}
    except Exception as e:
        return {"success": False, "error": str(e)}
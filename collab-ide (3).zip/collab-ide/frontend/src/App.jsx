import React, { useState, useEffect, useRef } from 'react';
import { BrowserRouter as Router, Routes, Route, useParams, useNavigate } from 'react-router-dom';
import MonacoEditor from '@monaco-editor/react';
import ParticipantList from './ParticipantList';
import AIReviewPanel from './AIReviewPanel';
import { Terminal } from 'xterm';
import 'xterm/css/xterm.css';

function Dashboard() {
  const [roomId, setRoomId] = useState('');
  const navigate = useNavigate();

  const createRoom = () => {
    const newRoomId = Math.random().toString(36).substr(2, 9);
    navigate(`/room/${newRoomId}`);
  };

  const joinRoom = () => {
    if (roomId.trim()) navigate(`/room/${roomId.trim()}`);
  };

  return (
    <div style={{ padding: '40px', fontFamily: 'Arial', textAlign: 'center' }}>
      <h1 style={{ fontSize: '48px', marginBottom: '10px' }}>Collaborative IDE</h1>
      <p style={{ fontSize: '18px', color: '#666', marginBottom: '40px' }}>
        Code together in real-time with AI assistance
      </p>

      <div style={{ marginTop: '40px' }}>
        <button
          onClick={createRoom}
          style={{
            padding: '15px 30px',
            fontSize: '18px',
            backgroundColor: '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            marginBottom: '20px'
          }}
        >
          ➕ Create New Room
        </button>

        <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginTop: '20px' }}>
          <input
            type="text"
            placeholder="Enter room ID..."
            value={roomId}
            onChange={(e) => setRoomId(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && joinRoom()}
            style={{
              padding: '12px',
              fontSize: '16px',
              width: '250px',
              border: '1px solid #ddd',
              borderRadius: '4px'
            }}
          />
          <button
            onClick={joinRoom}
            style={{
              padding: '12px 24px',
              fontSize: '16px',
              backgroundColor: '#28a745',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Join Room
          </button>
        </div>
      </div>
    </div>
  );
}

function Room() {
  const { roomId } = useParams();
  const [code, setCode] = useState('// Start coding...\n');
  const [language, setLanguage] = useState('python');
  const [participants, setParticipants] = useState(1);
  const [aiReviews, setAiReviews] = useState([]);
  const [clientId] = useState(() => `client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);

  const wsRef = useRef(null);
  const terminalRef = useRef(null);
  const termInstance = useRef(null);

  // --- Инициализация терминала ---
  useEffect(() => {
  const el = document.getElementById('terminal');
  if (el && !termInstance.current) {
    try {
      termInstance.current = new Terminal({
        cursorBlink: true,
        fontSize: 14,
        fontFamily: '"Fira Code", monospace',
        theme: { background: '#1e1e1e', foreground: '#d4d4d4' }
      });
      termInstance.current.open(el);
      termInstance.current.writeln('✅ Terminal ready. Click "Run Code" to execute.\n');
    } catch (err) {
      console.error('Failed to create terminal:', err);
    }
  }
}, []);

  // --- WebSocket ---
  useEffect(() => {
    if (!roomId) return;
    // ... (остальной WebSocket код — как у вас)
  }, [roomId, clientId]);

  const handleCodeChange = (value) => {
    setCode(value);
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'content_change', content: value, client_id: clientId }));
    }
  };

  const executeCode = async () => {
  if (!termInstance.current) {
    console.warn('Terminal not ready');
    return;
  }

  termInstance.current.writeln(`> Running ${language}...`, 'yellow');

  try {
    const res = await fetch('http://localhost:8000/api/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, language })
    });
    const result = await res.json();

    if (result.success) {
      // 🎯 ТОЛЬКО ВЫВОД КОДА — как в VS Code
      termInstance.current.writeln(result.output.trimEnd(), 'white');
    } else {
      termInstance.current.writeln(`Error: ${result.error}`, 'red');
    }
  } catch (err) {
    termInstance.current.writeln(`Network error: ${err.message}`, 'red');
  }
};

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      {/* Header */}
      <div style={{ padding: '15px 20px', backgroundColor: '#1e1e1e', color: 'white', display: 'flex', justifyContent: 'space-between' }}>
        <h2>Room: {roomId}</h2>
        <div>
          <select value={language} onChange={(e) => setLanguage(e.target.value)}>
            <option value="python">Python</option>
            <option value="javascript">JavaScript</option>
          </select>
          <button onClick={executeCode} style={{ marginLeft: '8px', backgroundColor: '#007bff', color: 'white', border: 'none', padding: '4px 12px' }}>
            ▶ Run
          </button>
        </div>
      </div>

      {/* Editor */}
      <MonacoEditor
        height="calc(100% - 200px)"
        language={language}
        value={code}
        onChange={handleCodeChange}
        theme="vs-dark"
        options={{ minimap: { enabled: true }, fontSize: 14 }}
      />

      {/* Terminal */}
      <div style={{ height: '200px', borderTop: '1px solid #333' }}>
        <div id="terminal" ref={terminalRef} style={{ height: '100%' }}></div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/room/:roomId" element={<Room />} />
      </Routes>
    </Router>
  );
}
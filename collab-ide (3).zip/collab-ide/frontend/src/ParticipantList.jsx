import React from 'react';

const ParticipantList = ({ participants, currentUserId }) => {
  return (
    <div>
      <h3>Participants ({participants.length})</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {participants.map((p, i) => (
          <li
            key={i}
            style={{
              padding: '8px',
              borderBottom: '1px solid #333',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          >
            <strong>{p.client_id === currentUserId ? 'You' : p.client_id}</strong>
            {p.client_id === currentUserId && (
              <span style={{ color: '#4caf50', fontSize: '12px' }}>(you)</span>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ParticipantList;
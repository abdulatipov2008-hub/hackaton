import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import MonacoEditor from '@monaco-editor/react';
import { Terminal } from 'xterm';
import 'xterm/css/xterm.css';
import ParticipantList from './ParticipantList.jsx';
import AIReviewPanel from './AIReviewPanel.jsx';
import './Editor.jsx';

const Editor = () => {
  const { roomId } = useParams();
  const [code, setCode] = useState('// Start coding...');
  const [participants, setParticipants] = useState([]);
  const [aiReviews, setAiReviews] = useState([]);
  const [language, setLanguage] = useState('python');
  const [clientId] = useState(() => `client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  
  const wsRef = useRef(null);
  const terminalRef = useRef(null);
  const termInstance = useRef(null);

  useEffect(() => {
    // Connect to WebSocket
    const wsUrl = `ws://localhost:8000/ws/${roomId}/${clientId}`;
    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      console.log('Connected to room:', roomId);
    };

    wsRef.current.onmessage = (event) => {
      const message = JSON.parse(event.data);
      handleMessage(message);
    };

    wsRef.current.onclose = () => {
      console.log('Disconnected from room');
    };

    // Initialize terminal
    initTerminal();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (termInstance.current) {
        termInstance.current.dispose();
      }
    };
  }, [roomId, clientId]);

  const handleMessage = (message) => {
    switch (message.type) {
      case 'init':
        setCode(message.content);
        setParticipants(message.participants);
        break;
      
      case 'content_change':
        if (message.client_id !== clientId) {
          setCode(message.content);
        }
        break;
      
      case 'participant_joined':
      case 'participant_left':
        // Update participants list
        fetchParticipants();
        break;
      
      case 'ai_review':
        setAiReviews(prev => [...prev, message.review]);
        break;
      
      default:
        console.log('Unknown message type:', message.type);
    }
  };

  const initTerminal = () => {
    const terminalElement = document.getElementById('terminal');
    if (terminalElement) {
      termInstance.current = new Terminal({
        cursorBlink: true,
        fontSize: 14,
        fontFamily: '"Fira Code", monospace',
        theme: {
          background: '#1e1e1e',
          foreground: '#d4d4d4'
        }
      });
      
      termInstance.current.open(terminalElement);
      termInstance.current.writeln('Welcome to Collaborative IDE Terminal');
      termInstance.current.writeln('Type commands to execute code...\n');
    }
  };

  const handleEditorChange = (value) => {
    setCode(value);
    
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'content_change',
        content: value,
        cursor: { line: 0, column: 0 } // Get actual cursor position
      }));
    }
  };

  const executeCode = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: code,
          language: language,
          timeout: 10
        })
      });
      
      const result = await response.json();
      
      if (termInstance.current) {
        if (result.success) {
          termInstance.current.writeln(result.output);
        } else {
          termInstance.current.writeln(`Error: ${result.error}`, 'red');
        }
      }
    } catch (error) {
      console.error('Execution error:', error);
    }
  };

  const fetchParticipants = async () => {
    try {
      const response = await fetch(`http://localhost:8000/api/rooms/${roomId}/participants`);
      const data = await response.json();
      setParticipants(data);
    } catch (error) {
      console.error('Error fetching participants:', error);
    }
  };

  return (
    <div className="editor-container">
      <div className="main-editor">
        <div className="editor-header">
          <select 
            value={language} 
            onChange={(e) => setLanguage(e.target.value)}
            className="language-select"
          >
            <option value="python">Python</option>
            <option value="javascript">JavaScript</option>
            <option value="java">Java</option>
          </select>
          <button onClick={executeCode} className="run-button">
            ▶ Run Code
          </button>
        </div>
        
        <MonacoEditor
          height="calc(100vh - 200px)"
          language={language}
          value={code}
          onChange={handleEditorChange}
          theme="vs-dark"
          options={{
            minimap: { enabled: true },
            fontSize: 14,
            automaticLayout: true,
            scrollBeyondLastLine: false
          }}
        />
      </div>
      
      <div className="side-panel">
        <ParticipantList participants={participants} currentUserId={clientId} />
        <AIReviewPanel reviews={aiReviews} />
      </div>
      
      <div className="terminal-container">
        <div id="terminal" ref={terminalRef}></div>
      </div>
    </div>
  );
};

export default Editor;
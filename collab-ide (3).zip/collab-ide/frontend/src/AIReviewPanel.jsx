import React from 'react';

const AIReviewPanel = ({ reviews }) => {
  return (
    <div>
      <h3>AI Review ({reviews.length})</h3>
      {reviews.length === 0 ? (
        <p style={{ color: '#aaa', fontStyle: 'italic' }}>No reviews yet</p>
      ) : (
        <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
          {reviews.map((r, i) => (
            <div key={i} style={{ margin: '8px 0', padding: '8px', background: '#333', borderRadius: '4px' }}>
              <div><strong>Score:</strong> {r.score || '?'} / 10</div>
              <div><strong>Issues:</strong> {r.issues?.length || 0}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AIReviewPanel;
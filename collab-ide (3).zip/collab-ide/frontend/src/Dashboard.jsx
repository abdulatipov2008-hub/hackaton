import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaPlus, FaFolder, FaUsers } from 'react-icons/fa';
import './Dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');

  const createRoom = async () => {
    const roomId = Math.random().toString(36).substr(2, 9);
    navigate(`/room/${roomId}`);
  };

  const joinRoom = (roomId) => {
    navigate(`/room/${roomId}`);
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Collaborative IDE</h1>
        <p>Code together in real-time with AI assistance</p>
      </header>

      <div className="actions">
        <button className="btn-primary" onClick={createRoom}>
          <FaPlus /> Create New Room
        </button>
        
        <div className="join-room">
          <input 
            type="text" 
            placeholder="Enter room ID..."
            onKeyPress={(e) => e.key === 'Enter' && joinRoom(e.target.value)}
          />
          <button onClick={() => {
            const input = document.querySelector('.join-room input');
            joinRoom(input.value);
          }}>
            Join
          </button>
        </div>
      </div>

      <div className="features">
        <div className="feature-card">
          <FaUsers className="feature-icon" />
          <h3>Real-time Collaboration</h3>
          <p>Code together with multiple users simultaneously</p>
        </div>
        
        <div className="feature-card">
          <FaFolder className="feature-icon" />
          <h3>Project Management</h3>
          <p>Organize your code in projects and files</p>
        </div>
        
        <div className="feature-card">
          <FaRobot className="feature-icon" />
          <h3>AI Code Review</h3>
          <p>Get instant feedback and suggestions from AI</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
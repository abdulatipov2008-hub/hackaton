# Collaborative IDE with AI Reviewer

Платформа для совместного программирования в реальном времени с AI-ревьюером.

## 🚀 Быстрый старт

### Требования
- Docker и Docker Compose
- Node.js 18+ (для локальной разработки)
- Python 3.11+ (для локальной разработки)
- OpenAI API ключ

### Установка

1. Клонируйте репозиторий:
```bash
git clone <your-repo-url>
cd collab-ide